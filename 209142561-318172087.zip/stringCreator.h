#ifndef HW5_STRINGCREATOR_H
#define HW5_STRINGCREATOR_H

#include <string>

using namespace std;

static unsigned int string_counter = 0;

class stringCreator {
public:
    string name;
    stringCreator();
};

#endif //HW5_STRINGCREATOR_H